/** Automatically generated file. DO NOT MODIFY */
package com.infamous.cm.theme1;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}